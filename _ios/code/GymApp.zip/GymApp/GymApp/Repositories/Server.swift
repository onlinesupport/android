//
//  Server.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 02/11/2021.
//

import Foundation
let SERVER_NAME = "https://jsonplaceholder.typicode.com"

