//
//  UserRepository.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 01/11/2021.
//

import Foundation

class UserRepository:ObservableObject {
    @Published var users: [User] = []
    @Published var isLoading:Bool = false
    func urlGetUsers() -> String {
        "\(SERVER_NAME)/users"
    }
    
    
    func getUsers(completion: @escaping (Result<[User], Error>) -> ()){
            isLoading = true
            guard let url = URL(string: urlGetUsers()) else {
                completion(.failure(UserException.responseError(errorCode: ErrorCode.invalidUrl, message: "Invalid url")))
                self.isLoading = false
                return
            }

            let urlRequest = URLRequest(url: url)

            let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                if let error = error {
                    print("Request error: ", error)
                    self.isLoading = false
                    completion(.failure(UserException.responseError(errorCode: ErrorCode.internalServerError, message:error.localizedDescription)))
                    return
                }

                guard let response = response as? HTTPURLResponse else {
                    
                    completion(.failure(UserException.responseError(
                                            errorCode: ErrorCode.notFound,
                                                                    message:error?.localizedDescription ?? "")))
                    self.isLoading = false
                    return
                }

                if response.statusCode == 200 {
                    guard let data = data else {
                        
                        completion(.failure(UserException.responseError(
                                                errorCode: ErrorCode.notFound,
                                                                        message:error?.localizedDescription ?? "")))
                        self.isLoading = false
                        return
                    }
                    DispatchQueue.main.async {
                        do {
                            let decodedUsers = try JSONDecoder().decode([User].self, from: data)
                            self.users = decodedUsers
                            completion(.success(decodedUsers))
                            self.isLoading = false
                        } catch let error {
                            
                            completion(.failure(UserException.responseError(errorCode: ErrorCode.internalServerError, message:error.localizedDescription)))
                            self.isLoading = false
                        }
                    }
                }
            }

            dataTask.resume()
        }
}


