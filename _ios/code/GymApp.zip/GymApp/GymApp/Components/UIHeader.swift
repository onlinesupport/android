//
//  UIHeader.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 29/10/2021.
//

import SwiftUI

struct UIHeader: View {
    private var onPressLeft:()->Void
    private var onPressRight:()->Void
    private var title:String
    init(onPressLeft:(()->Void)? = nil,
         onPressRight: (()->Void)? = nil, title: String) {
        self.onPressLeft = onPressLeft ?? {}
        self.onPressRight = onPressRight ?? {}
        self.title = title
    }
    var body: some View {
        HStack {
            Button(action: {
                self.onPressLeft()
            }){
                Image(Icons.back)
                    .renderingMode(.template)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 40)
                    .foregroundColor(Colors.primary)
                    .padding(.leading, 10)
            }
            Spacer()
            Text(title)
                .font(Font.custom("Roboto-Light", size: 16))
            Spacer()
            Button(action: {
                self.onPressRight()
            }) {
                
            }.padding(20)
        }.frame(height:50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
    }
}

struct UIHeader_Previews: PreviewProvider {
    static var previews: some View {
        UIHeader(onPressLeft: {
            print("aa")
        }, onPressRight: {
            print("aa")
        }, title: "haha")
    }
}
