//
//  Gender.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 30/10/2021.
//
//Identifiable is a protocol("interface") which must implement "id" property
struct Gender : Identifiable{
    let icon: String
    let text: String
    var isSelected: Bool
    //conform to Identifiable
    var id:String {icon}
}
