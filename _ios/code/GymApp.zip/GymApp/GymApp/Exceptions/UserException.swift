//
//  UserException.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 02/11/2021.
//

import Foundation
enum UserException: Error {
    case responseError(errorCode: Int, message: String)    
}
