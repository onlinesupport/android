//
//  Tabs.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 31/10/2021.
//

import SwiftUI

struct Tab {
    var icon: Image
    var title: String
}    
    
struct Tabs: View {
    var tabs: [Tab]
    var geoWidth: CGFloat
    @Binding var selectedTab: Int
    var body: some View {
        ScrollView(.horizontal) {
            ScrollViewReader { proxy in
                HStack(spacing: 0) {
                    ForEach(0 ..< tabs.count, id: \.self) { row in
                        let isSelected = row == selectedTab
                        Button(action: {
                            withAnimation {
                                selectedTab = row
                            }
                        }, label: {
                            VStack(alignment: .center, spacing: 0) {
                                // Image
                                tabs[row].icon
                                    .renderingMode(.template)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 15)
                                    .foregroundColor(isSelected ? Colors.primary : Colors.inactive)
                                Text(tabs[row].title)
                                    .font(Font.custom("Roboto-Light", size: 12))
                                    .foregroundColor(isSelected ? Colors.primary : Colors.inactive)
                                    .padding(.vertical, 5)
                            }.frame(width: geoWidth / CGFloat(tabs.count), height: 52)
                        })
                    }
                }
                .onChange(of: selectedTab) { target in
                    print("haha")
                    withAnimation {
                        proxy.scrollTo(target)
                    }
                }
            }
        }
        .frame(height: 55)
    }
}

struct Tabs_Previews: PreviewProvider {
    static var previews: some View {
        Tabs(
             tabs: [.init(icon: Image(systemName: "star.fill"), title: "Tab 1"),
                    .init(icon: Image(systemName: "star.fill"), title: "Tab 2"),
                    .init(icon: Image(systemName: "star.fill"), title: "Tab 3")],
             geoWidth: 375,
             selectedTab: .constant(0))
    }
}
