//
//  MyTab.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 31/10/2021.
//

import SwiftUI


struct MyTab: View {
    @State private var selectedTab: Int = 0
    
    let tabs: [Tab] = [
        Tab(icon: Image(Icons.plan), title: "Plan"),
        Tab(icon: Image(Icons.training), title: "Training"),
        Tab(icon: Image(Icons.food), title: "Food"),
        Tab(icon: Image(Icons.challenges), title: "Challenges"),
        Tab(icon: Image(Icons.profile), title: "Profile"),
    ]
    init() {
        //UINavigationBar.appearance().isTranslucent = true
    }
    var body: some View {
        NavigationView {
            GeometryReader { geometry in
                VStack(spacing: 0) {
                    TabView(selection: $selectedTab,
                            content: {
                                Plan().tag(0)
                                Training().tag(1)
                                Food().tag(2)
                                Challenges().tag(3)
                                Profile().tag(4)
                            })
                        .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                    Tabs(tabs: tabs, geoWidth: geometry.size.width, selectedTab: $selectedTab)
                }
                .foregroundColor(Colors.primary)
                .ignoresSafeArea()
            }
        }.navigationBarHidden(true)
    }
}
struct MyTab_Previews: PreviewProvider {
    static var previews: some View {
        MyTab()
    }
}
