//
//  GymAppApp.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 27/10/2021.
//

import SwiftUI

@main
struct GymAppApp: App {
    var userRepository = UserRepository()
    var body: some Scene {
        WindowGroup {
            MyTab()
                .environmentObject(userRepository)
                .onAppear(perform: {
                for fontFamily in UIFont.familyNames {
                    for fontName in UIFont.fontNames(forFamilyName: fontFamily) {
                        print("\(fontName)")
                    }
                }
                    
            })
        }
    }
}
