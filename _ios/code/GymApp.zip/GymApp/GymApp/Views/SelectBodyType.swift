//
//  SelectBodyType.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 30/10/2021.
//

import SwiftUI

struct SelectBodyType: View {
    @State private var bodyTypes:[BodyType] = [
        BodyType(icon: Icons.bodyShapeThin,text: "Thin",isSelected: false),
        BodyType(icon: Icons.bodyShapeNormal,text: "Normal",isSelected: false),
        BodyType(icon: Icons.bodyShapeFat,text: "Fat",isSelected: true)
    ]
    var body: some View {
        VStack{
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "")
            Group {
                Spacer()
                Text("What's your Body Type ?")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(Font.custom("Roboto-Bold", size: 20))
                    .padding()
                Spacer()
            }
            Group {
                HStack {
                    ForEach(Array(bodyTypes.enumerated()), id: \.offset) { index, bodyType in
                        VStack {
                            Image(bodyType.icon)
                                .renderingMode(.template)
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 80)
                                .foregroundColor(Colors.primary)
                            Spacer()
                            Text(bodyType.text)
                                .font(Font.custom("Roboto-Light", size: 16))
                        }
                        .padding(.vertical, 10)
                        .padding(.leading, 5)
                        .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Colors.primary, lineWidth: bodyType.isSelected ? 1 : 0)
                            )
                        .padding(.leading, 10)
                        .padding(.trailing, 10)
                        .padding(.vertical, 5)
                        .onTapGesture {
                            bodyTypes = bodyTypes.map({ eachGender in
                                var changedGender = eachGender
                                changedGender.isSelected = eachGender.icon == bodyType.icon
                                return changedGender
                            })
                        }
                    }
                }
                .frame(maxWidth: .infinity, maxHeight: 200, alignment: .center)
                
            }
            Spacer()
            Button(action: {
                
            }) {
                Text("NEXT")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(Colors.primary)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }.padding(.bottom, 10)            
        }
    }
}

struct SelectBodyType_Previews: PreviewProvider {
    static var previews: some View {
        SelectBodyType()
    }
}
