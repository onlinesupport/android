//
//  SelectGender.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 30/10/2021.
//

import SwiftUI

struct SelectGender: View {
    @State private var genders:[Gender] = [
        Gender(icon: Icons.male,text: "Male",isSelected: false),
        Gender(icon: Icons.female,text: "Female",isSelected: false),
        Gender(icon: Icons.nonBinary,text: "Male",isSelected: true)
    ]
    var body: some View {
        VStack{
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "")
            Group {
                Spacer()
                Text("What's your Gender ?")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .font(Font.custom("Roboto-Bold", size: 20))
                    .padding()
                Spacer()
            }
            Group {
                ForEach(genders) { gender in
                    HStack(spacing:10) {
                        Image(gender.icon)
                            .renderingMode(.template)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 30)
                            .foregroundColor(Colors.primary)
                        Text(gender.text)
                            .font(Font.custom("Roboto-Light", size: 16))
                        Spacer()
                    }
                    .padding(.vertical, 10)
                    .padding(.leading, 5)
                    .overlay(
                            RoundedRectangle(cornerRadius: 10)
                                .stroke(Colors.primary, lineWidth: gender.isSelected ? 1 : 0)
                        )
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .padding(.vertical, 5)
                    .onTapGesture {
                        genders = genders.map({ eachGender in
                            var changedGender = eachGender
                            changedGender.isSelected = eachGender.icon == gender.icon
                            return changedGender
                        })
                    }
                }
            }
            Spacer()
            Button(action: {
                
            }) {
                Text("NEXT")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(Colors.primary)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }.padding(.bottom, 10)
        }
    }
}

struct SelectGender_Previews: PreviewProvider {
    static var previews: some View {
        SelectGender()
    }
}
