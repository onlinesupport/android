//
//  Profile.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 31/10/2021.
//

import SwiftUI

struct Profile: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Profile")
                .foregroundColor(.black)
                .font(Font.system(size: 25, weight: .bold))
            Spacer()
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}
