//
//  Demo1View.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 31/10/2021.
//

import SwiftUI

struct Plan: View {
    @EnvironmentObject var userRepository: UserRepository
    var body: some View {
        ScrollView {
            VStack(alignment: .leading) {
                if(userRepository.isLoading == true) {
                    Spacer()
                    ProgressView()
                    Spacer()
                } else {
                    ForEach(userRepository.users) { user in
                        HStack(alignment:.top) {
                            Text("\(user.id)")
                            VStack(alignment: .leading) {
                                Text(user.name).bold().foregroundColor(Colors.primary)
                                Text(user.email.lowercased()).foregroundColor(.black)
                                Text(user.phone).foregroundColor(.black)
                            }
                            Spacer()
                        }
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color(#colorLiteral(red: 0.6667672396, green: 0.7527905703, blue: 1, alpha: 0.2662717301)))
                        .cornerRadius(10)
                    }
                }
            }
        }
        .frame(maxHeight: .infinity)
        .padding(.horizontal, 20)
        .navigationBarHidden(true)
        .onAppear {
            userRepository.getUsers { result in
                        
            }
        }       
    }
}

struct Plan_Previews: PreviewProvider {
    static var previews: some View {
        Plan()
            .environmentObject(UserRepository())
    }
}
