//
//  Challenges.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 31/10/2021.
//
import SwiftUI

struct Challenges: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Challenges")
                .foregroundColor(.black)
                .font(Font.system(size: 25, weight: .bold))
            Spacer()
        }
    }
}

struct Challenges_Previews: PreviewProvider {
    static var previews: some View {
        Challenges()
    }
}
