import SwiftUI

struct Food: View {
    var body: some View {
        VStack {
            Spacer()
            Text("Food")
                .foregroundColor(.black)
                .font(Font.system(size: 25, weight: .bold))
            Spacer()
        }
    }
}

struct Food_Previews: PreviewProvider {
    static var previews: some View {
        Food()
    }
}
