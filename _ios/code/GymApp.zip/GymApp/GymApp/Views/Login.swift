//
//  InputName.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//

import SwiftUI

struct Login: View {
    @State private var email: String = ""
    @State private var password: String = ""
    @State private var errorEmail: String = ""
    @State private var errorPassword: String = ""
    
    @State private var passwordVisible:Bool = false
    var body: some View {
        VStack(alignment: .leading) {
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "Login")
            TextField("Email", text: Binding<String>(get: {self.email}, set: {
                email = $0
                errorEmail = (isValidEmail(email: email) == false) ? "Email is not in correct format" : ""
            }))
                .keyboardType(.emailAddress)
                .disableAutocorrection(true)
                .autocapitalization(.none)
                .padding(.horizontal, 10)
                .padding(.top, 10)
                .multilineTextAlignment(.leading)
                .font(Font.custom("Roboto-Thin", size: 15))
            .accentColor(errorEmail == "" ? Colors.primary : .red)
            Divider()
                .padding(.horizontal, 10)
            Text(errorEmail)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(Font.custom("Roboto-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .foregroundColor(.red)
            ZStack(alignment: .bottomTrailing) {
                VStack {
                    if(passwordVisible == true) {
                        TextField("Password", text: Binding<String>(get: {self.password}, set: {
                            password = $0
                            errorPassword = password.count == 0 ? "Password must not be blank" : ""
                        }))
                        .keyboardType(.default)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .padding(.horizontal, 10)
                        .padding(.top, 10)
                        .multilineTextAlignment(.leading)
                        .font(Font.custom("Roboto-Thin", size: 15))
                    .accentColor(errorEmail == "" ? Colors.primary : .red)
                    } else {
                        SecureField("Password", text: Binding<String>(get: {self.password}, set: {
                            password = $0
                            errorPassword = password.count == 0 ? "Password must not be blank" : ""
                        }))
                        .keyboardType(.default)
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                        .padding(.horizontal, 10)
                        .padding(.top, 10)
                        .multilineTextAlignment(.leading)
                        .font(Font.custom("Roboto-Thin", size: 15))
                    .accentColor(errorEmail == "" ? Colors.primary : .red)
                    }
                    Divider()
                        .padding(.horizontal, 10)
                }
                Button(action: {
                    passwordVisible.toggle()
                }) {
                    Image(Icons.eye)
                        .renderingMode(.template)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 20, alignment: .topTrailing)
                        .foregroundColor(Colors.inactive)
                }
                .padding()
                .offset(x: 0, y: 4)
            }
            Text(errorPassword)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(Font.custom("Roboto-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .foregroundColor(.red)
            Group {
                HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                    Text("Don't have an account ?")
                        .frame(maxWidth: .infinity)
                        .font(Font.custom("Roboto-Thin", size: 16))
                        .multilineTextAlignment(.center)
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                }
                HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                    Spacer()
                    Button(action: {
                        
                    }) {
                        Text("Create account")
                            .font(Font.custom("Roboto-Light", size: 16))
                            .foregroundColor(.black)
                            .underline()
                            .padding(.vertical, 5)
                    }
                    Spacer()
                }
                HStack(alignment: .center) {
                    Spacer()
                    Button(action: {

                    }) {
                        Text("Forgot password ?")
                            .font(Font.custom("Roboto-Light", size: 16))
                            .foregroundColor(.black)
                            .underline()
                            .padding(.vertical, 5)
                    }
                    Spacer()
                }
            }
            Spacer()
            let hasNoError = errorEmail == "" && email.count > 0
                && errorPassword == "" && password.count > 0
            Button(action: {
                print("login")
            }) {
                Text("LOGIN")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(hasNoError ? Colors.primary : Colors.inactive)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }
            .padding(.bottom, 10)
            disabled(!hasNoError)
        }
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
