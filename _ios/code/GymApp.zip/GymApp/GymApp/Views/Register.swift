//
//  InputName.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//

import SwiftUI

struct Register: View {
    @State private var email: String = ""
    @State private var errorEmail: String = ""
    
    @State private var password: String = ""
    @State private var errorPassword: String = ""
    
    @State private var retypePassword: String = ""
    @State private var errorRetypePassword: String = ""
    
    @State private var passwordVisible:Bool = false
    var body: some View {
        VStack(alignment: .leading) {
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "Register")
            TextField("Email", text: Binding<String>(get: {self.email}, set: {
                email = $0
                errorEmail = (isValidEmail(email: email) == false) ? "Email is not in correct format" : ""
            }))
                .keyboardType(.emailAddress)
                .disableAutocorrection(true)
                .autocapitalization(.none)
                .padding(.horizontal, 10)
                .padding(.top, 10)
                .multilineTextAlignment(.leading)
                .font(Font.custom("Roboto-Thin", size: 15))
            .accentColor(errorEmail == "" ? Colors.primary : .red)
            Divider()
                .padding(.horizontal, 10)
            Text(errorEmail)
                .frame(maxWidth: .infinity, alignment: .leading)
                .font(Font.custom("Roboto-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .foregroundColor(.red)
            Group {
                ZStack(alignment: .bottomTrailing) {
                    VStack {
                        if(passwordVisible == true) {
                            TextField("Password", text: Binding<String>(get: {self.password}, set: {
                                password = $0
                                errorPassword = password.count == 0 ? "Password must not be blank" : ""
                            }))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("Roboto-Thin", size: 15))
                        .accentColor(errorPassword == "" ? Colors.primary : .red)
                        } else {
                            SecureField("Password", text: Binding<String>(get: {self.password}, set: {
                                password = $0
                                errorPassword = password.count == 0 ? "Password must not be blank" : ""
                            }))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("Roboto-Thin", size: 15))
                        .accentColor(errorPassword == "" ? Colors.primary : .red)
                        }
                        Divider()
                            .padding(.horizontal, 10)
                    }
                    Button(action: {
                        passwordVisible.toggle()
                    }) {
                        Image(Icons.eye)
                            .renderingMode(.template)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 20, alignment: .topTrailing)
                            .foregroundColor(Colors.inactive)
                    }
                    .padding()
                    .offset(x: 0, y: 4)
                }
                Text(errorPassword)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(Font.custom("Roboto-Light", size: 16))
                    .multilineTextAlignment(.center)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(.red)
                ZStack(alignment: .bottomTrailing) {
                    VStack {
                        if(passwordVisible == true) {
                            TextField("Retype password", text: Binding<String>(get: {self.retypePassword}, set: {
                                retypePassword = $0
                                errorPassword = retypePassword.count == 0 ? "Password must not be blank" : ""
                            }))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("Roboto-Thin", size: 15))
                        .accentColor(errorRetypePassword == "" ? Colors.primary : .red)
                        } else {
                            SecureField("Retype password", text: Binding<String>(get: {self.password}, set: {
                                password = $0
                                errorRetypePassword = retypePassword.count == 0 ? "Password must not be blank" : ""
                            }))
                            .keyboardType(.default)
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .autocapitalization(/*@START_MENU_TOKEN@*/.none/*@END_MENU_TOKEN@*/)
                            .padding(.horizontal, 10)
                            .padding(.top, 10)
                            .multilineTextAlignment(.leading)
                            .font(Font.custom("Roboto-Thin", size: 15))
                        .accentColor(errorRetypePassword == "" ? Colors.primary : .red)
                        }
                        Divider()
                            .padding(.horizontal, 10)
                    }
                    Button(action: {
                        passwordVisible.toggle()
                    }) {
                        Image(Icons.eye)
                            .renderingMode(.template)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 20, alignment: .topTrailing)
                            .foregroundColor(Colors.inactive)
                    }
                    .padding()
                    .offset(x: 0, y: 4)
                }
                Text(errorPassword)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .font(Font.custom("Roboto-Light", size: 16))
                    .multilineTextAlignment(.center)
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .foregroundColor(.red)
            }
            
            Group {
                HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                    Text("Already have an account ?")
                        .frame(maxWidth: .infinity)
                        .font(Font.custom("Roboto-Thin", size: 16))
                        .multilineTextAlignment(.center)
                        .padding(.leading, 20)
                        .padding(.trailing, 20)
                }
                HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                    Spacer()
                    Button(action: {
                        
                    }) {
                        Text("Login")
                            .font(Font.custom("Roboto-Light", size: 16))
                            .foregroundColor(.black)
                            .underline()
                            .padding(.vertical, 5)
                    }
                    Spacer()
                }
                HStack(alignment: .center) {
                    Spacer()
                    Button(action: {

                    }) {
                        Text("Forgot password ?")
                            .font(Font.custom("Roboto-Light", size: 16))
                            .foregroundColor(.black)
                            .underline()
                            .padding(.vertical, 5)
                    }
                    Spacer()
                }
            }
            Spacer()
            Button(action: {
                print("login")
            }) {
                Text("REGISTER")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(errorEmail == "" && email.count > 0
                                    && errorPassword == "" && password.count > 0
                                    ? Colors.primary : Colors.inactive)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }
            .padding(.bottom, 10)
            
        }
    }
}

struct Register_Previews: PreviewProvider {
    static var previews: some View {
        Register()
    }
}
