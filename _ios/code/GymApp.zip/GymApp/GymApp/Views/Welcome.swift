//
//  Welcome.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 27/10/2021.
//

import SwiftUI
/*
 Download SF Symbols 3, then install this app
 Open App and see all available icons

 */
struct Welcome: View {
    var body: some View{
        VStack(alignment: .leading, spacing: 10) {
            HStack {
                Image(Icons.logo)
                    .renderingMode(.template)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 30)
                    .foregroundColor(Colors.primary)
                    .padding(.leading, 10)
                Spacer()
                Button(action: {
                    print("Hello World")
                }) {
                    Text("SKIP").foregroundColor(Colors.primary)
                }.padding(.trailing, 10)
                    
            }
            Spacer()
            HStack {
                Spacer()
                Image(Images.welcome)
                    .renderingMode(.original)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .cornerRadius(20)
                Spacer()
            }
            HStack {
                Spacer()
                Text("Welcome to MyApp")
                    .font(Font.custom("Roboto-Bold", size: 17))
                Image(systemName: "heart.circle")
                    .font(Font.system(size: 20))
                    .foregroundColor(Colors.primary)
                    .padding(.leading, -5)
                Spacer()
            }
            Text("Improve your health with gym, meal plans and calorie tracker")
                .multilineTextAlignment(.center)
                .font(Font.custom("Roboto-Light", size: 16))
                .padding(.leading, 20)
                .padding(.trailing, 20)
                .padding(.bottom, 20)
            
            
            Button(action: {
                print("login")
            }) {
                Text("LOGIN")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(Colors.primary)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }
            Button(action: {
                print("Create account")
            }) {
                Text("Create Account")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(Colors.primary)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
                    .padding(.top, -10)
            }
            HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                Text("By continuing you accept our")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .font(Font.custom("Roboto-Thin", size: 16))
                    .multilineTextAlignment(.center)
                    .padding(.leading, 20)
                    .padding(.trailing, 20)
            }
            HStack(alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/) {
                Spacer()
                Button(action: {
                    
                }) {
                    Text("Privacy Policy")
                        .font(Font.custom("Roboto-Light", size: 16))
                        .foregroundColor(Colors.inactive)
                        .underline()
                }
                Text("and")
                    .font(Font.custom("Roboto-Light", size: 16))
                    .foregroundColor(Colors.inactive)
                Button(action: {
                    
                }) {
                    Text("Terms of Use")
                        .font(Font.custom("Roboto-Light", size: 16))
                        .foregroundColor(Colors.inactive)
                        .underline()
                }
                Spacer()
            }
            Spacer()
        }
    }
}

struct Welcome_Previews: PreviewProvider {
    static var previews: some View {
        Welcome()
    }
}
