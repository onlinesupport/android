//
//  SelectIngredient.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 30/10/2021.
//

import SwiftUI

struct SelectIngredients: View {
    @State private var ingredients:[Ingredient] = [
        Ingredient(
            icon: Icons.broccoli,
            text: "Broccoli",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.sweetPotato,
            text: "Sweet potato",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.mushroom,
            text: "Mushroom",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.tomato,
            text: "Tomato",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.peas,
            text: "Peas",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.spinach,
            text: "Spinach",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.zucchini,
            text: "Succhini",
            isSelected: false
            ),
        Ingredient(
            icon: Icons.pepper,
            text: "Pepper",
            isSelected: false
            ),
    ]
    let columns = [
        GridItem(.adaptive(minimum: 100)),
        GridItem(.adaptive(minimum: 100))
    ]
    
    var body: some View {
        let selectedIngredients = ingredients.filter {
            $0.isSelected == true
        }
        VStack{
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "")
            Group {
                Spacer()
                Text("Pick the ingredients you wish ?")
                    .frame(maxWidth: .infinity, alignment: .center)
                    .multilineTextAlignment(.center)
                    .font(Font.custom("Roboto-Bold", size: 28))
                    .padding()
                Spacer()
            }
            Group {
                ScrollView {
                    LazyVGrid(columns: columns, spacing: 10) {
                        ForEach(ingredients) { ingredient in
                            HStack(spacing:10) {
                                Image(ingredient.icon)
                                    .renderingMode(.template)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 30)
                                    .foregroundColor(Colors.primary)
                                Text(ingredient.text)
                                    .font(Font.custom("Roboto-Light", size: 16))
                                Spacer()
                            }
                            .padding(.vertical, 10)
                            .padding(.leading, 5)
                            .overlay(
                                RoundedRectangle(cornerRadius: 10)
                                    .stroke(Colors.primary, lineWidth: ingredient.isSelected ? 1 : 0)
                            )
                            .padding(.leading, 10)
                            .padding(.trailing, 10)
                            .padding(.vertical, 5)
                            .onTapGesture {
                                ingredients = ingredients.map({ eachIngredient in
                                    var changedIngredient = eachIngredient
                                    changedIngredient.isSelected = changedIngredient.icon == ingredient.icon ? !changedIngredient.isSelected : changedIngredient.isSelected
                                    return changedIngredient
                                })
                            }
                            .frame(height: 70)
                        }
                    }
                    .padding(.horizontal)
                }
                .frame(maxHeight: 300)
            }
            Spacer()
            Button(action: {
                print("haha")
            }) {
                Text("NEXT")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(selectedIngredients.count > 0 ? Colors.primary : Colors.inactive)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }.padding(.bottom, 10)
            .disabled(selectedIngredients.count == 0)
        }
    }
}

struct SelectIngredients_Previews: PreviewProvider {
    static var previews: some View {
        SelectIngredients()
    }
}
