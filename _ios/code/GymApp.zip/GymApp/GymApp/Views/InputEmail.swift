//
//  InputName.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//

import SwiftUI

struct InputEmail: View {
    @State var email: String = ""
    @State var error: String = ""
    var body: some View {
        VStack(alignment: .leading) {
            UIHeader(
                onPressLeft: {
                    print("left")
                }, onPressRight: {
                    print("right")
                }, title: "")
            Text("What's your email ?")
                .frame(maxWidth: .infinity, alignment: .center)
                .font(Font.custom("Roboto-Bold", size: 20))
                .padding()
            TextField("", text: Binding<String>(get: {self.email}, set: {
                email = $0
                error = (isValidEmail(email: email) == false) ? "Email is not in correct format" : ""
            }))
                .keyboardType(.emailAddress)
                .disableAutocorrection(true)
                .padding(.leading, 20)
                .padding(.trailing, 20)
                .multilineTextAlignment(.center)
                .font(Font.custom("Roboto-Thin", size: 30))
                .accentColor(error == "" ? Colors.primary : .red)
            Rectangle()
                .fill(error == "" ? Colors.primary : .red)
                .frame(height: 1, alignment: .center)
                .padding(.leading, 30)
                .padding(.trailing, 30)
            Text(error)
                .frame(maxWidth: .infinity, alignment: .center)
                .font(Font.custom("Roboto-Light", size: 16))
                .multilineTextAlignment(.center)
                .padding(.leading, 10)
                .padding(.trailing, 10)
                .foregroundColor(.red)
            Spacer()
            Button(action: {
                
            }) {
                Text("NEXT")
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .foregroundColor(.white)
                    .background(error == "" && email.count > 0 ? Colors.primary : Colors.inactive)
                    .clipShape(RoundedRectangle(cornerRadius: 25))
                    .padding(.leading, 10)
                    .padding(.trailing, 10)
            }.padding(.bottom, 10)
            .disabled(error.count > 0 || email.count == 0)
        }
    }
}

struct InputEmail_Previews: PreviewProvider {
    static var previews: some View {
        InputEmail()
    }
}
