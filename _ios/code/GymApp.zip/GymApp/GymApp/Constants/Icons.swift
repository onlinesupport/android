//
//  Icons.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//
import SwiftUI

class Icons{
    static var logo = "logo"
    static var back = "icon-back"
    static var zucchini = "icon-zucchini"    
    static var bodyShapeFat = "icon-body-shape-fat"
    static var bodyShapeNormal = "icon-body-shape-normal"
    static var bodyShapeThin = "icon-body-shape-thin"
    static var broccoli = "icon-broccoli"
    static var buildMuscle = "icon-build-muscle"
    static var challenges = "icon-challenges"
    static var eye = "icon-eye"
    static var female = "icon-female"
    static var food = "icon-food"
    static var keepFit = "icon-keep-fit"
    static var loseWeight = "icon-lose-weight"
    static var male = "icon-male"
    static var mushroom = "icon-mushroom"
    static var nonBinary = "icon-non-binary"
    static var peas = "icon-peas"
    static var pepper = "icon-pepper"
    static var plan = "icon-plan"
    static var profile = "icon-profile"
    static var spinach = "icon-spinach"
    static var sweetPotato = "icon-sweet-potato"
    static var tomato = "icon-tomato"
    static var training = "icon-training"
}
