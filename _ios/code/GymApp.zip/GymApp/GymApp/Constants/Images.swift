//
//  Images.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//
import SwiftUI

class Images{
    static var welcome = "welcome"
}
