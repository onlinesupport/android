//
//  Colors.swift
//  GymApp
//
//  Created by Nguyen Duc Hoang on 28/10/2021.
//

import SwiftUI

class Colors{
    static var primary = Color(red: 171/255, green: 48/255, blue: 138/255)
    static var inactive = Color(red: 127/255, green: 127/255, blue: 127/255)
    //ab308a
}
