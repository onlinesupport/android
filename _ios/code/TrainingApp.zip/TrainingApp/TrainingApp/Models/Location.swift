//
//  Location.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation
class Location:NSCopying {
    func copy(with zone: NSZone? = nil) -> Any {
        //clone 
        return Location(latitude: latitude, longitude: longitude)
    }
    
    var latitude:Float = 0.0
    var longitude:Float = 0.0
    init(latitude: Float, longitude: Float) {
        self.latitude = latitude
        self.longitude = longitude
    }
    //toString = implement "getter" description
    var description: String {
        return "latitude = \(latitude), longitude = \(longitude)"
    }
}
