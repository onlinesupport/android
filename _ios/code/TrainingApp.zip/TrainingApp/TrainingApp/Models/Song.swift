//
//  Song.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import Foundation
struct Song:Identifiable {
    var name: String = ""
    var id: String {name} //primary key
    var author: String = ""
    var numberOfLikes: Int = 0
    var numberOfDisLikes: Int = 0
    var url: String = ""
    var isSelected:Bool = false
}
