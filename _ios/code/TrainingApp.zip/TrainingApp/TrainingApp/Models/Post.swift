//
//  Post.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 10/11/2021.
//

import Foundation
struct Post: Identifiable, Decodable {
    var id:Int
    var body:String
    var title:String
}
