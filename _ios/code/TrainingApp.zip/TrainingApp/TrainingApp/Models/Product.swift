//
//  Product.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation

class Product {
    var productName: String
    var price:Double? //? = optional = can be nil =
    var description:String? //Optional<Product>
    
    init() {
        productName = ""
    }
    func methodA(x: Int, y: Int) -> Int {
        print("this is method A")
        return x + y
    }
    func methodB() {
        print("tuple example")
        //tuple
        let personA = ("Hoang", "hoang@gmail.com", 44)
        //destructure a tuple
        let (name, email, age) = personA
        print("name = \(name), email = \(email), age = \(age)")
        //Dictionary
        var dictPerson = [String: Any]()
        dictPerson["name"] = "Hoang"
        dictPerson["age"] = 44 //Any is Int
        //dictPerson["location"] = (123, 456) // Any is tuple, object
        dictPerson["location"] = Location(latitude: 11, longitude: 22)
        print((dictPerson["location"] as! Location).description)
        //dictPerson["something"] = [1,2,4,5,6]        
    }
}
