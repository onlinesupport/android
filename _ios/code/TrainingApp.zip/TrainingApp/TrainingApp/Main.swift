//
//  TrainingAppApp.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import SwiftUI

@main
struct Main: App {
    //Dependency Injection
    var postRepository = PostRepository()
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Welcome()
                    .onAppear(){
                        print("haha")
                    for family in UIFont.familyNames {

                        let sName: String = family as String
                        print("family: \(sName)")
                                
                        for name in UIFont.fontNames(forFamilyName: sName) {
                            print("name: \(name as String)")
                        }
                    }
                }
                    .ignoresSafeArea()
            }
            //Dependency Injection
            .navigationBarHidden(true)
            .environmentObject(postRepository)
        }
    }
}
