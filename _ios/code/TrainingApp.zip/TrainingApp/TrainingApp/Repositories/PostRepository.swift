//
//  UserRepository.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 10/11/2021.
//

import Foundation
//this will be "Observable object"
//1.init PostRepository
//2.call getPosts
import Alamofire

class PostRepository:ObservableObject {
    @Published var posts: [Post] = [] //Global states = global object AND observable
    @Published var isLoading:Bool = false//initial state
    @Published var error:String = ""//initial state
    
    func urlGetPosts(pageNumber: Int, limit: Int) -> String {
        "https://\(SERVER_NAME)/posts?page=\(pageNumber)&limit=\(limit)"
    }
    
    func getPostsUsingAlamofire(pageNumber: Int, limit: Int) {
        guard let url = URL(string: urlGetPosts(pageNumber: pageNumber, limit: limit)) else {
                        self.isLoading = false
                        return
                    }
        AF.request(url).response { response in
            switch response.result {
                case .success(let data):
                do {
                    if let data = data {
                        let decodedPosts = try JSONDecoder().decode([Post].self, from: data)
                        //self.posts = "published" object
                        self.posts = decodedPosts
                        self.error = ""
                        self.isLoading = false
                    }
                } catch let error1 {
                    self.posts = []
                    self.error = "eee:  \(error1)"
                    self.isLoading = false
                }
                
                case .failure(let error):
                    print("Something went wrong: \(error)")
                }
            debugPrint(response)
        }
    }

    func getPosts(pageNumber: Int, limit: Int) {
        self.isLoading = true
        guard let url = URL(string: urlGetPosts(pageNumber: pageNumber, limit: limit)) else {
                        self.isLoading = false
                        return
                    }
        let urlRequest = URLRequest(url: url)
        //async Task
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                        if let error = error {
                            print("Request error: ", error)
                            self.posts = []
                            self.error = "Request error: \(error)"
                            self.isLoading = false
                            return
                        }

                        guard let response = response as? HTTPURLResponse else {
                            self.posts = []
                            self.error = "null response"
                            self.isLoading = false
                            return
                        }
                        //rsponse not nil
                        if response.statusCode == 200 {
                            guard let data = data else {
                                
                                self.posts = []
                                self.error = "null response with errr"
                                self.isLoading = false
                                return
                            }
                            //response is ok!
                            
                            DispatchQueue.main.async {
                                do {
                                    let decodedPosts = try JSONDecoder().decode([Post].self, from: data)
                                    //self.posts = "published" object
                                    self.posts = decodedPosts
                                    self.error = ""
                                    self.isLoading = false
                                } catch let error1 {
                                    self.posts = []
                                    self.error = "eee:  \(error1)"
                                    self.isLoading = false
                                }
                            }
                        }
                    }

                    dataTask.resume()
    }
    
    /*
    func getPosts(pageNumber: Int, limit: Int,
                  completion: @escaping (Result<[Post], Error>) -> ()) {
        self.isLoading = true
        guard let url = URL(string: urlGetPosts(pageNumber: pageNumber, limit: limit)) else {
                        completion(.failure(PostException.responseError(errorCode: ErrorCode.invalidUrl, message: "Invalid url")))
                        self.isLoading = false
                        return
                    }
        let urlRequest = URLRequest(url: url)
        //async Task
        let dataTask = URLSession.shared.dataTask(with: urlRequest) { (data, response, error) in
                        if let error = error {
                            print("Request error: ", error)
                            self.isLoading = false
                            completion(.failure(PostException.responseError(errorCode: ErrorCode.internalServerError, message:error.localizedDescription)))
                            return
                        }

                        guard let response = response as? HTTPURLResponse else {
                            
                            completion(.failure(PostException.responseError(
                                                    errorCode: ErrorCode.notFound,
                                                                            message:error?.localizedDescription ?? "")))
                            self.isLoading = false
                            return
                        }
                        //rsponse not nil
                        if response.statusCode == 200 {
                            guard let data = data else {
                                
                                completion(.failure(PostException.responseError(
                                                        errorCode: ErrorCode.notFound,
                                                                                message:error?.localizedDescription ?? "")))
                                self.isLoading = false
                                return
                            }
                            //response is ok!
                            
                            DispatchQueue.main.async {
                                do {
                                    let decodedPosts = try JSONDecoder().decode([Post].self, from: data)
                                    //self.posts = "published" object
                                    self.posts = decodedPosts
                                    completion(.success(decodedPosts))
                                    self.isLoading = false
                                } catch let error {
                                    completion(.failure(PostException.responseError(errorCode: ErrorCode.internalServerError, message:error.localizedDescription)))
                                    self.isLoading = false
                                }
                            }
                        }
                    }

                    dataTask.resume()
    }
     */
}
