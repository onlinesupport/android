//
//  AppTab.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI
struct Tab {
    var icon: Image
    var title: String
}

struct AppTab: View {
    @State private var selectedTab: Int = 0
        let tabs: [Tab] = [
            Tab(icon: Image(AppIcons.phone), title: "Songs"),
            Tab(icon: Image(AppIcons.heart), title: "Favorites"),
            Tab(icon: Image(AppIcons.user), title: "User"),
            Tab(icon: Image(AppIcons.star), title: "Stars"),
        ]
        init() {
            UINavigationBar.appearance().isTranslucent = true
        }
        var body: some View {
            NavigationView {
                GeometryReader { geometry in
                    VStack(spacing: 0) {
                        TabView(selection: $selectedTab,
                                content: {
                                    MusicList().tag(0)
                                    Favorite().tag(1)
                                    User().tag(2)
                                    Star().tag(3)
                                })
                            .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                        Tabs(tabs: tabs, geoWidth: geometry.size.width, selectedTab: $selectedTab)
                    }
                    .foregroundColor(AppColors.primary)
                }
            }
            .ignoresSafeArea()
            .navigationBarHidden(true)
        }
}

struct Tabs: View {
    var tabs: [Tab]
    var geoWidth: CGFloat
    @Binding var selectedTab: Int
    var body: some View {
        ScrollView(.horizontal) {
            ScrollViewReader { proxy in
                HStack(spacing: 0) {
                    ForEach(0 ..< tabs.count, id: \.self) { row in
                        let isSelected = row == selectedTab
                        Button(action: {
                            withAnimation {
                                selectedTab = row
                            }
                        }, label: {
                            VStack(alignment: .center, spacing: 0) {
                                // Image
                                tabs[row].icon
                                    .renderingMode(.template)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 15)
                                    .foregroundColor(isSelected ? AppColors.primary : AppColors.inactive)
                                Text(tabs[row].title)
                                    .foregroundColor(isSelected ? AppColors.primary : AppColors.inactive)
                                    .padding(.vertical, 5)
                            }.frame(width: geoWidth / CGFloat(tabs.count), height: 52)
                        })
                    }
                }
                .onChange(of: selectedTab) { selectedIndex in
                    print("haha")
                    if(selectedTab == 1) {
                        print("favorite appear: \(selectedIndex)")
                    }
                    withAnimation {
                        proxy.scrollTo(selectedIndex)
                    }
                }
            }
        }
        .frame(height: 55)
    }
}

struct AppTab_Previews: PreviewProvider {
    static var previews: some View {
        AppTab()
    }
}


