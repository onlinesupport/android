//
//  File.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 11/11/2021.
//

import UIKit
import SwiftUI
class UserViewController: UIViewController {
    override func viewDidLoad() {
//        let label = UILabel(frame: CGRect(x: 0, y: 0, width: 200, height: 21))
//            label.center = CGPoint(x: 160, y: 285)
//            label.textAlignment = .center
//            label.text = "I'm a test label"
        setupViews()
        
    }
    override func viewWillAppear(_ animated: Bool) {
        
    }
}
extension UserViewController {
    func imageViewLogo() -> UIImageView{
        let image = UIImageView(image: UIImage(named: "google"))
        image.translatesAutoresizingMaskIntoConstraints = false
        return image
    }
    func labelLogo() -> UILabel {
        let label = UILabel()
        label.text = "This is Star"
        label.sizeToFit()
        label.font = .systemFont(ofSize: 20)
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }
    private func setupViews() {
        let imageViewLogo = imageViewLogo()
        self.view.addSubview(imageViewLogo)
        imageViewLogo.centerXAnchor.constraint(equalTo: self.view.centerXAnchor).isActive = true
        imageViewLogo.centerYAnchor.constraint(equalTo: self.view.centerYAnchor).isActive = true
        imageViewLogo.widthAnchor.constraint(equalToConstant: 100).isActive = true
        imageViewLogo.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        let labelLogo = labelLogo()
        self.view.addSubview(labelLogo)
        labelLogo.topAnchor
            .constraint(equalTo: imageViewLogo.bottomAnchor, constant: 20).isActive = true
        labelLogo.centerXAnchor.constraint(equalTo: imageViewLogo.centerXAnchor).isActive = true
    }
}
