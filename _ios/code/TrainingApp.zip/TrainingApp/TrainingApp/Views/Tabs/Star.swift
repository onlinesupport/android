//
//  Star.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI
//old docs: RxSwift(NO)
struct Star: View {
    @EnvironmentObject var postRepository: PostRepository
    var body: some View {
        if(postRepository.posts.count > 0) {
            Text("Has dataaaa")
        } else {
            Text("haha")
        }
        
    }
}

struct Star_Previews: PreviewProvider {
    static var previews: some View {
        Star()
    }
}
