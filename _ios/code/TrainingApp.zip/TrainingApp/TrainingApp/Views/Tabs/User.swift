//
//  User.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI
import UIKit
//This tab will use UIViewController
struct User: UIViewControllerRepresentable {
    typealias UIViewControllerType = UserViewController
    func makeUIViewController(context: Context) -> UserViewController {
        let userViewController = UserViewController()
        return userViewController
    }
    func updateUIViewController(_ uiViewController: UserViewController, context: Context) {
        
    }
}

struct User_Previews: PreviewProvider {
    static var previews: some View {
        User()
    }
}
