//
//  MusicList.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI

struct MusicList: View {
    @State var songs = [
        Song(
            name: "Ch345345ac ai do se quay ve",
            author: "656Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "Chac ai d45345o se quay ve",
            author: "767Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "44Chac ai do se quay ve",
            author: "787Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "5656Chac ai do se quay ve",
            author: "67Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "5788Chac ai do se quay ve",
            author: "66Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "99Chac ai do se quay ve",
            author: "656Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        Song(
            name: "66Chac ai do se quay ve",
            author: "33Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ),
        
    ]
    
    var body: some View {
        UITableView.appearance().backgroundColor = .clear
        UITableViewCell.appearance().backgroundColor = .clear
        //Add "selected items"
        return VStack {
            List {
                ForEach(songs, id: \.id) { song in
                    Button(action: {
                        self.songs = self.songs.map({
                            var modifiedSong = $0
                            if(song.id == $0.id) {
                                modifiedSong.isSelected = !modifiedSong.isSelected
                            }
                            
                            return modifiedSong
                        })
                    }) {
                        SongListItem(song: song)
                    }
                }.listRowBackground(Color.white)
            }
            .background(Color.white)
            
        }
        .background(Color.white)
        .navigationBarHidden(true)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
        
    }
}

struct MusicList_Previews: PreviewProvider {
    static var previews: some View {
        MusicList()
    }
}
