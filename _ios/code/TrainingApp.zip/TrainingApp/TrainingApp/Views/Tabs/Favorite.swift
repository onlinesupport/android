//
//  Phone.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI

struct Favorite: View {
    //call api here ? NO!
    @EnvironmentObject var postRepository: PostRepository
    @State private var pageNumber: Int = 0
    @State private var limit: Int = 0
    var body: some View {
            ScrollView {
                VStack(alignment: .leading) {
                    if(postRepository.isLoading == true) {
                        Spacer()
                        ProgressView()
                        Spacer()
                    } else {
                        ForEach(postRepository.posts) { post in
                            VStack(alignment: .leading) {
                                Text(post.body)
                                    .foregroundColor(Color.black)
                                Text(post.title)
                                    .foregroundColor(Color.black)
                            }
                        }
                    }
                }
            }
            .frame(maxHeight: .infinity)
            .padding(.horizontal, 20)
            .navigationBarHidden(true)
            .onAppear {
                print("kaka")
                //postRepository.getPosts(pageNumber: 1, limit:10)
                postRepository.getPostsUsingAlamofire(pageNumber: self.pageNumber, limit: self.limit)
            }
        }
}

struct Favorite_Previews: PreviewProvider {
    static var previews: some View {
        Favorite()
    }
}
