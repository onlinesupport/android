//
//  Welcome.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import SwiftUI

struct Welcome: View {
    @State private var showNextScreen = false;
    var body: some View {
            VStack {
                HStack {
                    Spacer()
                    NavigationLink(destination: InputName(), isActive: $showNextScreen) {
                        Button(action: {
                            print("press Skip")
                            showNextScreen = true
                        }){
                            Text("SKIP")
                                .foregroundColor(Color.white)
                                .font(.system(size: FontSizes.h6))
                                .padding()
                        }
                    }                    
                }
                .frame(height: 60, alignment: .leading)
                .padding()
                VStack {
                    Spacer()
                    Image(AppImages.logo)
                        .renderingMode(.original)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 200)
                            .foregroundColor(AppColors.primary)

                    Spacer()
                }
                .frame(width: UIScreen.screenWidth)
                VStack {
                    DashedLine(
                        space: 10,
                        numberOfItems: 5)
                        .padding(.top, 10)
                    Text("somethiong interrsjiung gg")
                        .font(.custom("DancingScript-Bold", size: FontSizes.h1))
                        .fontWeight(/*@START_MENU_TOKEN@*/.bold/*@END_MENU_TOKEN@*/)
                        .padding()
                    Text("Not the answer you're looking for? Browse other questions taggeddd")
                        .font(.system(size: FontSizes.h5))
                        .foregroundColor(AppColors.inactive)
                    Button(action: {
                        print("Create account")
                    }) {
                        Text("Create Account".uppercased())
                            .foregroundColor(Color.white)
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .background(AppColors.primary)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                            .padding(.leading, 20)
                            .padding(.trailing, 20)
                            .padding(.top, 10)
                    }
                    HStack {
                        Button(action: {
                            print("haha")
                        }) {
                            Text("Have an account?")
                                .foregroundColor(Color.black)
                                .font(.system(size: FontSizes.h6))
                        }
                        .padding(.vertical, 15)
                        Button(action: {
                            print("haha11")
                        }) {
                            Text("Have an account?")
                                .foregroundColor(Color.black)
                                .font(.system(size: FontSizes.h6))
                                .bold()
                        }
                        .padding(.vertical, 15)
                    }.padding(.top, 10)
                    Spacer()
                    
                }
                .frame(width: UIScreen.screenWidth - 30)
                .background(Color.white)
                .clipShape(RoundedRectangle(cornerRadius: 10))
                .padding()
            }.background(AppColors.primary)
            .navigationTitle("")
            .navigationBarHidden(true)
    }
}
func doSomething(){
    let x = 1 //let = constant = final(Java) = NOT "freeze object"
    //x = 122
    let y = 2
    let z: Int = 120
    var product:Product? = Product()
    product?.productName = "iphone X"
    let sum = product?.methodA(x: 2, y: 3)
    print("sum = \(sum ?? 0)") //elvis operator => default value
    product = Product()
    print("x = \(x), y = \(y)") //string concatenation
    product?.methodB()
    //struct and class, what is the diff ?
    //named parameters
    var location1 = Location(latitude: 11, longitude: 22)
    var location2 = location1.copy()
    location1.latitude = 999
    print("haha")
    print("server's name : \(SERVER_NAME)")

    let color1 = UIColor(red: 150/255, green: 160/255, blue: 180/255, alpha: 1.0) //complicated
    //let color2 = UIColor(150, 160, 180) //simpler
    
    //color1.doSomething()
}
struct Welcome_Previews: PreviewProvider {
    static var previews: some View {
        Welcome()
    }
}
