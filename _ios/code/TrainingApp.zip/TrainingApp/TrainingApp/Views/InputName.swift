//
//  InputName.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 11/11/2021.
//

import SwiftUI

struct InputName: View {
    @State var name: String = ""//initial state NOT NULL
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            UIHeader(onPressLeft: {
                //navigation back swiftui
                self.presentationMode.wrappedValue.dismiss()
            }, onPressRight: {
                
            }, title: "Your name")
            Text("Input your name")
                .font(.system(size: FontSizes.h1))
                .bold()
            TextField(self.name,
                      //two-ways data binding
                      text: Binding<String>(get: {
                self.name
            }, set: {
                self.name = $0
            }))
                .keyboardType(.emailAddress)
                .foregroundColor(AppColors.primary)
                .background(Color.yellow)
            Spacer()
            Button(action: {
                print("NEXT")
            }) {
                Text("NEXT".uppercased())
                    .foregroundColor(Color.white)
                    .frame(maxWidth: .infinity, minHeight: 50)
                    .background(AppColors.primary)
                    .clipShape(RoundedRectangle(cornerRadius: 5))
                    .padding(.leading, 20)
                    .padding(.trailing, 20)
                    .padding(.top, 10)
            }
        }.navigationBarHidden(true)
    }
        
}

struct InputName_Previews: PreviewProvider {
    static var previews: some View {
        InputName()
    }
}
