//
//  Login.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI

struct Login: View {
    @State var email: String = ""//initial state NOT NULL
    @State var password: String = ""
    @State var isRememberMe: Bool = false
    @State private var isShowingAppTab = false
    var body: some View {
        NavigationView {
            VStack {
               Text("Login")
                .font(.system(size: FontSizes.h2))
                .bold()
                .foregroundColor(Color.white)
                .padding(.top, 100)
                HStack {
                    Text("Email")
                        .font(.system(size: FontSizes.h5))
                        .foregroundColor(Color.white)
                        .padding(.top, 10)
                        .padding(.horizontal, 20)
                    Spacer()
                }
                HStack {
                    //SF icons = Sans Fransisco
                    Image(systemName: "mail")
                        .foregroundColor(Color.white)
                        .padding(.vertical, 30)
                        .padding(.leading, 20)
                    ZStack(alignment: .leading) {
                        if(self.email.isEmpty) {
                                Text("Enter your email")
                                    .foregroundColor(AppColors.inactive)
                        }
                        TextField(self.email,
                                  //two-ways data binding
                                  text: Binding<String>(get: {
                            self.email
                        }, set: {
                            self.email = $0
                        }))
                            .keyboardType(.emailAddress)
                            .foregroundColor(Color.white)
                    }
                    
                    Spacer()
                }
                .overlay(RoundedRectangle(cornerRadius: 10)
                            .stroke(AppColors.inactive, lineWidth: 1)
                            .frame(maxHeight: 50)
                            .padding(.horizontal, 10)
                )
                HStack {
                    //SF icons = Sans Fransisco
                    Image(systemName: "person")
                        .foregroundColor(Color.white)
                        .padding(.vertical, 30)
                        .padding(.leading, 20)
                    ZStack(alignment: .leading) {
                        if(self.password.isEmpty) {
                                Text("Enter your password")
                                    .foregroundColor(AppColors.inactive)
                        }
                        SecureField(self.password,text: Binding<String>(get: {
                            self.password
                        }, set: {
                            self.password = $0
                        }))
                            .foregroundColor(Color.white)
                    }
                    Spacer()
                }
                .overlay(RoundedRectangle(cornerRadius: 10)
                            .stroke(AppColors.inactive, lineWidth: 1)
                            .frame(maxHeight: 50)
                            .padding(.horizontal, 10)
                )
                HStack {
                    Spacer()
                    Text("Forgot me?")
                        .font(.system(size: FontSizes.h5))
                        .foregroundColor(Color.white)
                        .padding(.trailing, 10)
                }
                HStack {
                    Button(action: {
                        self.isRememberMe = !self.isRememberMe
                    }) {
                        HStack(alignment: .center) {
                            if(!self.isRememberMe) {
                                Image(systemName: "square")
                                    .foregroundColor(Color.white)
                                    .padding(.leading, 20)
                            } else {
                                Image(systemName: "checkmark.square")
                                    .foregroundColor(Color.white)
                                    .padding(.leading, 20)
                            }
                            Text("Remember me")
                                .font(.system(size: FontSizes.h5))
                                .foregroundColor(Color.white)
                        }
                        .frame(maxHeight: 50)
                    }
                    
                    Spacer()
                }
                
                NavigationLink(destination: AppTab(), isActive: $isShowingAppTab) {
                    Button(action: {
                        print("Login")
                        print("ko login duoc")
                        //self.isShowingAppTab = true
                    }) {
                        Text("Login".uppercased())
                            .foregroundColor(AppColors.primary)
                            .frame(maxWidth: .infinity, minHeight: 50)
                            .background(Color.white)
                            .clipShape(RoundedRectangle(cornerRadius: 5))
                            .padding(.leading, 20)
                            .padding(.trailing, 20)
                            .padding(.top, 10)
                    }
                }
                HStack {
                    Image(AppIcons.facebook)
                        .renderingMode(.original)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 60)
                            .foregroundColor(AppColors.primary)
                        .padding(.trailing, 10)
                    Image(AppIcons.google)
                        .renderingMode(.original)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(height: 60)
                            .foregroundColor(AppColors.primary)
                        .padding(.leading, 10)
                }.padding(.top, 10)
                Spacer()
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(AppColors.primary)
            .ignoresSafeArea()
        }
        .navigationTitle("")
        .navigationBarHidden(true)
    }
}

struct Login_Previews: PreviewProvider {
    static var previews: some View {
        Login()
    }
}
