//
//  UIColor+Extensions.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation
import SwiftUI
//extension(category) = add more methods to existing Class
extension Color {
    init(_ red: Int, _ green: Int, _ blue: Int) {
        //CG = Core Graphics
        self.init(red: Double(red)/255, green: Double(green)/255, blue: Double(blue)/255)
    }
    
    //var x: Int?//cannot add more property to an existing class
    func doSomething() {
        print("do do...")
    }
}
