//
//  FontSizes.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Combine
import Foundation
import CoreGraphics

class FontSizes {
    static let h1:CGFloat = 30
    static let h2:CGFloat = 28
    static let h3:CGFloat = 25
    static let h4:CGFloat = 23
    static let h5:CGFloat = 20
    static let h6:CGFloat = 15
}
