//
//  AppIcons.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI
class AppIcons {
    static let facebook = "facebook"
    static let google = "google"
    //tabs
    static let phone = "phone"
    static let heart = "heart"
    static let user = "user"
    static let star = "star"
    
    static let back = "back"
}
