//
//  Server.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation
//Java style
//class Server {
//    static let SERVER_NAME = "localhost"
//    static let PORT = "3001"
//}

let SERVER_NAME = "jsonplaceholder.typicode.com"
let PORT = "3001"
