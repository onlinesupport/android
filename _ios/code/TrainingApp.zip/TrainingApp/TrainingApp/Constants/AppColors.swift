//
//  AppColors.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation
import SwiftUI
class AppColors {        
    static let primary = Color(224, 98, 137)
    static let inactive = Color.black.opacity(0.5)
}
