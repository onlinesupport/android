//
//  AppImages.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import Foundation
class AppImages {
    static let logo = "logo"
}
