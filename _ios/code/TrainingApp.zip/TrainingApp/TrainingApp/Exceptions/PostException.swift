//
//  PostException.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 10/11/2021.
//

import Foundation
import Foundation
enum PostException: Error {
    case responseError(errorCode: Int, message: String)
}
