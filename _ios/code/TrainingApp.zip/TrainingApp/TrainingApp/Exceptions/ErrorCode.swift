//
//  ErrorCode.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 10/11/2021.
//

import Foundation
struct ErrorCode {
    static var invalidUrl = 400
    static var unauthorized = 401
    static var forbidden = 403
    static var notFound = 404
    static var errorDecoding = 404
    static var internalServerError = 500
}
