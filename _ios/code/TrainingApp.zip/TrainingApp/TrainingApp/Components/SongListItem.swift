//
//  SongListItem.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 09/11/2021.
//

import SwiftUI
import URLImage
struct SongListItem: View {
    var song:Song
    var body: some View {
        HStack {
            let url:URL = URL(string: song.url)!
            
//            URLImage(url) { image in
//                image
//                    .resizable()
//                    .aspectRatio(contentMode: .fit)
//            }
            VStack(alignment: .leading, spacing: 5) {
                Text(song.name)
                    .foregroundColor(AppColors.primary)
                    .bold()
                Text(song.author)
                    .foregroundColor(Color.black)
                HStack {
                    Text("\(song.numberOfLikes)").foregroundColor(Color.black)
                    Image(systemName: "hand.thumbsup")
                        .foregroundColor(Color.black)
                    Text("\(song.numberOfLikes)")
                    Image(systemName: "hand.thumbsdown")
                        .foregroundColor(Color.black)
                        .foregroundColor(Color.black)
                }
                
            }
            Spacer()
        }
        .frame(maxWidth: .infinity)
        .background(song.isSelected ? AppColors.primary : Color.white)
    }
}

struct SongListItem_Previews: PreviewProvider {
    static var previews: some View {
        SongListItem(song: Song(
            name: "66Chac ai do se quay ve",
            author: "33Son Tung mtp",
            numberOfLikes: 100,
            numberOfDisLikes: 200,
            url: "https://event.mediacdn.vn/2020/8/14/st-15973999489741584015103.jpg"
        ))
    }
}
