//
//  UIHeader.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 11/11/2021.
//

import SwiftUI
struct UIHeader: View {
    var onPressLeft:(()->Void)?
    var onPressRight:(()->Void)?
    var title:String = ""
    
    var body: some View {
        HStack {
            Button(action: {
                if let onPressLeft = self.onPressLeft {
                    onPressLeft()
                }
            }){
                Image(AppIcons.back)
                    .renderingMode(.template)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(height: 40)
                    .foregroundColor(AppColors.primary)
                    .padding(.leading, 10)
            }
            Spacer()
            Text(title)
                .font(.system(size: FontSizes.h4))
            Spacer()
            Button(action: {
                if let onPressRight = self.onPressRight {
                    onPressRight()
                }
            }) {
                
            }.padding(20)
        }.frame(height:50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
    }
}

struct UIHeader_Previews: PreviewProvider {
    static var previews: some View {
        UIHeader()
    }
}
