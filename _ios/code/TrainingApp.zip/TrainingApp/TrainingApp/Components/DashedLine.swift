//
//  DashedLine.swift
//  TrainingApp
//
//  Created by Nguyen Duc Hoang on 08/11/2021.
//

import SwiftUI

struct DashedLine: View {
    var space: CGFloat
    var numberOfItems: Int
    init(space: CGFloat, numberOfItems: Int) {
        self.space = space
        self.numberOfItems = numberOfItems
    }
    var body: some View {
        HStack {
            ForEach(0..<numberOfItems * 2, id: \.self) {  item in
                Rectangle()
                    .fill(item % 2 == 0 ? Color.black : Color.black.opacity(0))
                    .frame(width: space, height: 2, alignment: .center)
                    .padding(.top, 10)
            }
                        
        }.frame(width: 100, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
    }
}

struct DashedLine_Previews: PreviewProvider {
    static var previews: some View {
        DashedLine(space: 10, numberOfItems: 5)
    }
}
